OPENAI_API_KEY = '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'
class Config(object):
    DEBUG = True
    TESTING = False

class DevelopmentConfig(Config):
    SECRET_KEY = "this-is-a-super-secret-key"

config = {
    'development': DevelopmentConfig,
    'testing': DevelopmentConfig,
    'production': DevelopmentConfig
}

