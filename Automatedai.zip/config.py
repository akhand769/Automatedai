OPENAI_API_KEY = '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'
class Config(object):
    DEBUG = True
    TESTING = False

class DevelopmentConfig(Config):
    SECRET_KEY = "this-is-a-super-secret-key"

config = {
    'development': DevelopmentConfig,
    'testing': DevelopmentConfig,
    'production': DevelopmentConfig
}

